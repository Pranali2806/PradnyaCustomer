import { Component, OnInit,Input } from '@angular/core';
import { Customer } from '../models/customer';
import { CustomerService } from '../services/customer.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  //to create new employee or edit it
  @Input() customer: Customer;


  constructor(private custService: CustomerService) {
    this.customer = new Customer(); 

  }
  ngOnInit() {
  }

  add() {
    this.custService.store(this.customer);
    this.customer = new Customer();
  }
}
