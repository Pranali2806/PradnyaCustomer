import { Injectable } from '@angular/core';
import {Customer} from '../models/customer';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  customerArr: Customer[];


  constructor(private routes:Router) {
    this.customerArr=[];
   }

   store(customer: Customer) {
    customer.custId= Math.floor(Math.random() * 100);
    this.customerArr.push(customer);
    this.routes.navigate(['/display']);
  }
  getCustomer() {
    return this.customerArr;
  }
}
